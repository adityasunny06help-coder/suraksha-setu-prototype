# Suraksha Setu — AI Scam Shield for Bharat

**CodeQuest: National Tech Hackathon 2026 (DotRepo) — Prototype Submission**
Team Aditya | Aditay Kumar

## Problem
First-time smartphone users and elders in Bharat lose money daily to phishing links, fake KYC messages, UPI collect-request fraud and OTP scams. Warnings are in English, technical, and arrive *after* the tap.

## Solution (Working MVP in this repo)
A pre-tap scam shield: paste any link / UPI ID / suspicious message and get, in seconds —
- A 0–100 risk score from a heuristic risk engine (IP-based URLs, suspicious TLDs, link shorteners, bank-impersonation + KYC/block language, OTP-ask patterns, lottery bait, urgency pressure, UPI collect-fee patterns, `@` URL tricks)
- A clear verdict in simple language: Safe / Caution / Danger
- Reason-by-reason explanation in Hinglish
- Voice alert (Web Speech API, Hindi) for low-literacy users — no reading needed
- One-tap Family Alert flow (prototype)

## Tech Stack
HTML5, CSS3, Vanilla JavaScript (zero dependencies, runs offline), Web Speech API for voice alerts. Planned next: on-device ML classifier (TinyBERT/MiniLM), QR-code scanning, share-intent integration.

## Run / Setup
No build, no install:
1. Open `index.html` in any browser, OR
2. `python3 -m http.server 8000` in this folder and open http://localhost:8000
Try the 3 built-in samples: scam KYC link, safe bank link, OTP scam message.

## Screenshots / Demo
Open the app and use the sample buttons — each shows score, verdict, reasons and voice alert.
Demo flow: Paste → Scan → Score + reasons → Voice Alert → Family Alert.

## Impact
Targets the exact moment of loss (the tap), in the user's own language, on low-end phones, with no login and no data leaving the device.
